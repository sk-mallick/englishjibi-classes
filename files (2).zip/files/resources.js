/* ═══════════════════════════════════════════════════════
   ENGLISHJIBI · Resources Page — behavior
   ═══════════════════════════════════════════════════════ */

/* ── Sample content ───────────────────────────────────────
   fileUrl is null until real PDFs are uploaded — handleDownload()
   shows a friendly "coming soon" toast in the meantime, same
   pattern the homepage already uses for its syllabus modal.  */
const featuredResources = [
    { id: 'fr1', title: 'Tenses Workbook', classLabel: 'Class 9', category: 'workbooks', group: 'Grammar', icon: 'book-open', tone: 'royal',
      desc: 'Detailed notes, examples and exercises on all types of tenses — built for exam-ready grammar accuracy.', fileUrl: null },
    { id: 'fr2', title: 'Vocabulary Builder', classLabel: null, category: 'vocabulary', group: 'Vocabulary', icon: 'languages', tone: 'gold',
      desc: 'Improve your vocabulary with meanings, usage examples and practice exercises drawn from NCERT-level passages.', fileUrl: null },
    { id: 'fr3', title: 'Sample Paper 2024-25', classLabel: 'Class 10', category: 'sample-papers', group: 'Sample Paper', icon: 'file-text', tone: 'navy',
      desc: 'The latest Class 10 sample paper with a complete, step-by-step solution key for self-assessment.', fileUrl: null },
    { id: 'fr4', title: 'English Workbook', classLabel: 'Class 8', category: 'workbooks', group: 'Workbook', icon: 'pencil', tone: 'cobalt',
      desc: 'Practice exercises across grammar and comprehension to strengthen everyday English skills.', fileUrl: null },
];

const recentResources = [
    { id: 'ra1', title: 'Class 9 Grammar Notes', subtitle: 'Voice (Active & Passive)', size: '1.2 MB', classLabel: 'Class 9', category: 'classes', fileUrl: null },
    { id: 'ra2', title: 'Class 8 Workbook', subtitle: 'Writing Skills', size: '980 KB', classLabel: 'Class 8', category: 'workbooks', fileUrl: null },
    { id: 'ra3', title: 'Class 10 Sample Paper', subtitle: 'English (2023-24)', size: '1.5 MB', classLabel: 'Class 10', category: 'sample-papers', fileUrl: null },
    { id: 'ra4', title: 'Class 6 Vocabulary', subtitle: 'Words & Meanings', size: '870 KB', classLabel: 'Class 6', category: 'vocabulary', fileUrl: null },
];

let activeFilters = { category: null, classLabel: null, query: '' };

const categoryDisplayNames = {
    workbooks: 'Workbooks', 'sample-papers': 'Sample Papers', 'answer-sheets': 'Answer Sheets',
    vocabulary: 'Vocabulary', syllabus: 'Syllabus', classes: 'Classes',
};
const categoryScrollTargets = {
    classes: 'browse-by-class', workbooks: 'featured-resources', 'sample-papers': 'featured-resources',
    'answer-sheets': 'featured-resources', vocabulary: 'featured-resources', syllabus: 'featured-resources',
    'recently-added': 'recently-added',
};

/* ── Filtering + rendering ────────────────────────────── */
function matchesFilters(item) {
    if (activeFilters.category && item.category !== activeFilters.category) return false;
    if (activeFilters.classLabel && item.classLabel !== activeFilters.classLabel) return false;
    if (activeFilters.query) {
        const q = activeFilters.query.toLowerCase();
        const haystack = `${item.title} ${item.desc || item.subtitle || ''} ${item.classLabel || ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
    }
    return true;
}

function resourceCardHTML(r) {
    return `
    <div class="ink-card overflow-hidden">
        <div class="resource-cover tone-${r.tone}">
            <i data-lucide="${r.icon}"></i>
            <span>${r.title}</span>
            ${r.classLabel ? `<small>${r.classLabel}</small>` : ''}
        </div>
        <div class="resource-card-body">
            <h3 class="type-h3" style="font-size:1rem;">${r.title}</h3>
            <p>${r.desc}</p>
            <div class="flex flex-wrap gap-2">
                <button class="btn-secondary text-xs py-2 px-4" onclick="openResourceModal('${r.id}')">View Details</button>
                <button class="btn-primary text-xs py-2 px-4" onclick="handleDownload('${r.id}')"><i data-lucide="download" class="w-3.5 h-3.5"></i> Download</button>
            </div>
        </div>
    </div>`;
}

function recentCardHTML(r) {
    return `
    <div class="recent-card">
        <div class="recent-card-icon"><i data-lucide="file-text"></i></div>
        <div style="min-width:0; flex:1;">
            <div class="flex items-center gap-2 flex-wrap">
                <span class="recent-card-title">${r.title}</span>
                <span class="badge badge-popular" style="font-size:0.6rem; padding:0.15rem 0.5rem;">NEW</span>
            </div>
            <div class="recent-card-sub">${r.subtitle}</div>
            <div class="recent-card-meta">
                <span>PDF · ${r.size}</span>
                <button class="recent-download-btn" onclick="handleDownload('${r.id}')" aria-label="Download ${r.title}"><i data-lucide="download"></i></button>
            </div>
        </div>
    </div>`;
}

function emptyStateHTML(message) {
    return `<div class="ink-card" style="grid-column:1/-1; padding:2.5rem 1.5rem; text-align:center;">
        <i data-lucide="folder-open" class="w-8 h-8" style="color:var(--text-muted); margin:0 auto 0.75rem;"></i>
        <p style="color:var(--text-muted); font-size:0.9rem;">${message}</p>
    </div>`;
}

function renderFeaturedResources() {
    const grid = document.getElementById('featured-resources-grid');
    if (!grid) return;
    const filtered = featuredResources.filter(matchesFilters);
    grid.innerHTML = filtered.length
        ? filtered.map(resourceCardHTML).join('')
        : emptyStateHTML('No resources tagged here just yet — more are added every week. Check back soon!');
    if (window.lucide) lucide.createIcons();
    updateFilterLabel();
}

function renderRecentResources() {
    const row = document.getElementById('recent-resources-row');
    if (!row) return;
    const filtered = recentResources.filter(matchesFilters);
    row.innerHTML = filtered.length
        ? filtered.map(recentCardHTML).join('')
        : `<div style="padding:1rem 0.25rem; color:var(--text-muted); font-size:0.85rem;">No recent resources match this filter yet.</div>`;
    if (window.lucide) lucide.createIcons();
}

function renderClassPills() {
    const row = document.getElementById('class-pill-row');
    if (!row) return;
    let html = '';
    for (let i = 1; i <= 10; i++) {
        const label = `Class ${i}`;
        html += `<button type="button" class="class-pill" data-class="${label}" onclick="toggleClassFilter('${label}', this)"><i data-lucide="graduation-cap"></i> ${label}</button>`;
    }
    row.innerHTML = html;
    if (window.lucide) lucide.createIcons();
}

function updateFilterLabel() {
    const label = document.getElementById('featured-filter-label');
    if (!label) return;
    const parts = [];
    if (activeFilters.category) parts.push(categoryDisplayNames[activeFilters.category] || activeFilters.category);
    if (activeFilters.classLabel) parts.push(activeFilters.classLabel);
    if (activeFilters.query) parts.push(`"${activeFilters.query}"`);
    label.textContent = parts.length ? `Filtered: ${parts.join(' · ')} — Clear` : 'View All Resources';
}

/* ── Filter interactions ──────────────────────────────── */
function toggleClassFilter(label, btn) {
    if (activeFilters.classLabel === label) {
        activeFilters.classLabel = null;
        btn.classList.remove('selected');
    } else {
        activeFilters.classLabel = label;
        document.querySelectorAll('.class-pill').forEach((p) => p.classList.remove('selected'));
        btn.classList.add('selected');
    }
    renderFeaturedResources();
    renderRecentResources();
    scrollToSection('featured-resources');
}

function jumpToCategory(key) {
    if (key === 'recently-added') {
        clearResourceFilters();
        scrollToSection('recently-added');
        return;
    }
    if (key === 'classes') {
        activeFilters.category = null;
    } else {
        activeFilters.category = key;
    }
    renderFeaturedResources();
    renderRecentResources();
    scrollToSection(categoryScrollTargets[key] || 'featured-resources');
}

function clearResourceFilters() {
    activeFilters = { category: null, classLabel: null, query: '' };
    const searchInput = document.getElementById('resource-search-input');
    if (searchInput) searchInput.value = '';
    document.querySelectorAll('.class-pill').forEach((p) => p.classList.remove('selected'));
    renderFeaturedResources();
    renderRecentResources();
}

function handleResourceSearch(e) {
    e.preventDefault();
    const input = document.getElementById('resource-search-input');
    activeFilters.query = input.value.trim();
    renderFeaturedResources();
    renderRecentResources();
    scrollToSection('featured-resources');
}

function scrollToSection(id) {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ── Resource modal ───────────────────────────────────── */
function openResourceModal(id) {
    const r = featuredResources.find((x) => x.id === id) || recentResources.find((x) => x.id === id);
    if (!r) return;
    document.getElementById('resource-modal-title').textContent = r.title;
    document.getElementById('resource-modal-badge').textContent = r.classLabel || r.group || 'Resource';
    document.getElementById('resource-modal-desc').textContent = r.desc || r.subtitle || '';
    const downloadBtn = document.getElementById('resource-modal-download');
    downloadBtn.onclick = () => handleDownload(r.id);
    document.getElementById('resource-modal').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeResourceModal() {
    const modal = document.getElementById('resource-modal');
    if (modal) modal.classList.remove('active');
    document.body.style.overflow = '';
}

function handleDownload(id) {
    const r = featuredResources.find((x) => x.id === id) || recentResources.find((x) => x.id === id);
    if (r && r.fileUrl) {
        window.open(r.fileUrl, '_blank');
    } else {
        showToast('This resource will be available for download soon.');
    }
}

/* ── Recently Added carousel ──────────────────────────── */
function scrollRecent(direction) {
    const row = document.getElementById('recent-resources-row');
    if (!row) return;
    row.scrollBy({ left: direction * 300, behavior: 'smooth' });
}

/* ── WhatsApp update signup ───────────────────────────── */
function handleWhatsAppSubmit(e) {
    e.preventDefault();
    const input = document.getElementById('whatsapp-phone-input');
    const phone = input.value.trim();
    if (!/^\d{10}$/.test(phone)) {
        showToast('Please enter a valid 10-digit WhatsApp number.');
        return;
    }
    const message = `Hello! Please add +91${phone} to the ENGLISHJIBI Classes WhatsApp updates list for notes, workbooks, sample papers and exam alerts.`;
    window.open(`https://wa.me/918328922917?text=${encodeURIComponent(message)}`, '_blank');
    showToast('Opening WhatsApp — send the message to confirm!');
    input.value = '';
}

/* ── Toast ─────────────────────────────────────────────── */
let toastTimer = null;
function showToast(message) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

/* ── FAQ accordion ─────────────────────────────────────── */
function toggleFaq(btn) {
    const item = btn.closest('.faq-item');
    if (!item) return;
    const isOpen = item.classList.toggle('open');
    btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
}

/* ── Mobile menu ───────────────────────────────────────── */
function toggleMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    const toggleBtn = document.getElementById('menu-toggle');
    if (!menu) return;
    const isOpen = menu.style.maxHeight && menu.style.maxHeight !== '0px';
    if (!isOpen) {
        menu.style.maxHeight = menu.scrollHeight + 'px';
        if (toggleBtn) { toggleBtn.setAttribute('aria-expanded', 'true'); toggleBtn.setAttribute('aria-label', 'Close menu'); }
    } else {
        closeMobileMenu();
    }
}
function closeMobileMenu() {
    const menu = document.getElementById('mobile-menu');
    const toggleBtn = document.getElementById('menu-toggle');
    if (menu) menu.style.maxHeight = '0px';
    if (toggleBtn) { toggleBtn.setAttribute('aria-expanded', 'false'); toggleBtn.setAttribute('aria-label', 'Open menu'); }
}
document.addEventListener('click', function (e) {
    const nav = document.getElementById('main-nav');
    const menu = document.getElementById('mobile-menu');
    if (menu && menu.style.maxHeight && menu.style.maxHeight !== '0px') {
        if (nav && !nav.contains(e.target)) closeMobileMenu();
    }
});

/* ── Nav scroll shadow ─────────────────────────────────── */
window.addEventListener('scroll', () => {
    const nav = document.getElementById('main-nav');
    if (!nav) return;
    if (window.scrollY > 60) nav.classList.add('scrolled'); else nav.classList.remove('scrolled');
});

/* ── Scroll reveal ─────────────────────────────────────── */
function initAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
        });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    document.querySelectorAll('.reveal-on-scroll:not(.is-visible)').forEach((el) => observer.observe(el));
}

/* ── Keyboard ──────────────────────────────────────────── */
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeResourceModal();
});

/* ── Init ──────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
    renderClassPills();
    renderFeaturedResources();
    renderRecentResources();

    const searchForm = document.getElementById('resource-search-form');
    if (searchForm) searchForm.addEventListener('submit', handleResourceSearch);

    const waForm = document.getElementById('whatsapp-update-form');
    if (waForm) waForm.addEventListener('submit', handleWhatsAppSubmit);

    function initLucideIcons() {
        if (window.lucide && typeof lucide.createIcons === 'function') { lucide.createIcons(); return true; }
        return false;
    }
    if (!initLucideIcons()) {
        let attempts = 0;
        const checkLucide = setInterval(() => { if (initLucideIcons() || ++attempts > 50) clearInterval(checkLucide); }, 100);
    }

    setTimeout(initAnimations, 100);
});
